# Ejercicio 3 de LMS

## Descripción

Este proyecto es un ejercicio de HTML y CSS relacionado con Breaking Bad.

## Funcionalidades

- **Diseño responsive**: La página se adaptará a diferentes dispositivos y tamaños de pantalla.

## Tecnologías utilizadas

- **FIGMA** para el diseño.
- **HTML5** y **CSS3** para la estructura y el estilo.
- **JavaScript** para la interactividad.
