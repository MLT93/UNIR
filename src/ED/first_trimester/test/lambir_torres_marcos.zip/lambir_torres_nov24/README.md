#_carpeta3_ lambir_torres_nov24
ED UNIR Practical Test First Trimester

### `Explicación de pasos seguidos:`

#### Paso 1. Creación y clonado del repositorio en GitHub

  - Creación del nombre del repo
  - Creación del README por defecto
  - Clonado del repositorio en local a través de clave SSH con: `git clone git@github.com:_mi-cuenta_/_nombre-repo_.git`

#### Paso 2. Uso de la terminal

  - Abro terminal con `Ctrl + Alt`
  - Búsqueda y navegación para encontrar el repositorio clonado. Se ha utilizaron comandos como: `ll -h`, `ll`, `cd` y `cd ..`
  - Apertura del repositorio con VSCode debido a la costumbre: `code _nombre-repo_`
  - Creación de carpetas con: `mkdir _carpeta1_ && mkdir _carpeta2_ && mkdir _carpeta3_ && mkdir _carpeta4_`
  - Muevo carpetas creadas a la carpeta del proyecto debido a confusión en la creación de las mismas: `mv _nombre-carpeta/_ _nombre-carpeta-destino/_`. Se repite tantas veces como carpetas se desean mover
  - Check de la corrección: `ll -h`
  - Me muevo a la carpeta del proyecto con: `cd _nombre-carpeta/_`. Se tabula mientras se escribe para agilizar el proceso
  - Intento crear un archivo y moverlo directamente a la carpeta aunque recuerdo mal el comando o la combinación de ellos, así que me muevo de una carpeta a otra para crear los archivos interesados.
  - Se crea también la carpeta **top_secret** la cual estaba sin especificar en el tercer punto del enunciado propuesto con: `mkdir`
  - Se descarga el enunciado del ejercicio práctico, se navega al directorio personal y se mueve ese archivo a la carpeta inherente. Comandos usados: `cd ~` y `mv ~/directorio...`
  - Se crea un archivo cualquiera con extensión **.png** sin embargo se elimina debido a que debe ser una imagen real. Comandos usados: `touch _nombre-archivo_`, `rm _nombre-archivo.png_` y `ll`
  - Se descarga el archivo, se le modifica el nombre y se mueve a la carpeta de destino. Comandos: `cd ~`, renombrado con `mv _nombre-archivo_ _logo.png_` y `mv logo.png _carpeta-destino/_`
  - Se crea el **.gitignore** y se modifica con un editor en terminal **vim**: `touch .gitignore` y `vim .gitignore`
  - Se realizan los cambios pertinentes dentro del editor **vim**, se crea un archivo **photoshop.xsd** y se comprueba el estado del repositorio: `touch photoshop.xsd` y `git status`
  - Cambio de directorio y vuelta a probar
  - Se crea nueva rama con: `git checkout -b "_nombre-rama_"
  - Al utilizar el comando checkout, éste hace un switch a la rama creada directamente
  - Se modifica **README.md** con VSCode: `code README.md`
  - Voy al repo desde la plataforma GitHub y agrego colaborador, **El Súper**
  - Tomo las capturas de pantalla, creo archivo history.log para evidenciar el uso de la terminal, hago el **push** y comprimo archivo local
