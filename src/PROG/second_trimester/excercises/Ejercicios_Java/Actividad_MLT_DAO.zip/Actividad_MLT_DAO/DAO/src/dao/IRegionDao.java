package dao;

import javabean.Region;

public interface IRegionDao extends ICrudGenerico<Region, Integer>{
	
}
