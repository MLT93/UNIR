package dao;

import javabean.Job;

public interface IJobDao extends ICrudGenerico<Job, String>{

}
