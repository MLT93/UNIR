package dao;

import javabean.Department;

public interface IDepartmentDao extends ICrudGenerico<Department, Integer>{

}
