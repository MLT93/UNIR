/**
 * 
 */
/**
 * 
 */
module JDBC_Files_MarcosLambirTorres {
	requires java.sql;
}